﻿using Microsoft.AspNetCore.Mvc;

namespace proje_1.Models
{
     public class Soru_ekle
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Content { get; set; }
    }
}
