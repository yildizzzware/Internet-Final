﻿using Microsoft.EntityFrameworkCore;

namespace proje_1.Models
{
    public class SoruDbContext : DbContext
    {
        public SoruDbContext(DbContextOptions<SoruDbContext> options) : base(options)
        {
        }

        public DbSet<Soru> Sorular { get; set; }
        public DbSet<Cevap> Cevaplar { get; set; }
    }

    public class Soru
    {
        public int SoruId { get; set; }
        public string SoruMetni { get; set; }

        // Gerekirse diğer özellikler eklenebilir.

        public virtual ICollection<Cevap> Cevaplar { get; set; }
    }

    public class Cevap
    {
        public int CevapId { get; set; }
        public string CevapMetni { get; set; }

        // Gerekirse diğer özellikler eklenebilir.

        public int SoruId { get; set; }
        public virtual Soru Soru { get; set; }
    }
}
