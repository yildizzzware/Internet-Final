﻿using Microsoft.AspNetCore.Mvc;
using proje_1.Models;


namespace proje_1.Controllers
{
    public class SorularController : Controller
    {
        private readonly SoruDbContext _context;

        public SorularController(SoruDbContext context)
        {
            _context = context;
        }

       

        [HttpPost]
        public ActionResult SaveUser(string CevapMetni)
        {
            var cevap = new Cevap { CevapMetni = CevapMetni };
            _context.Cevaplar.Add(cevap);

            _context.SaveChanges();

            return RedirectToAction("Sorular");
        }





        public IActionResult Sorular()
        {
            return View();
        }


       
    }
}
