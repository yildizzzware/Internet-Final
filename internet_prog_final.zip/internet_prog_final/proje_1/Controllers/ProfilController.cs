﻿using Microsoft.AspNetCore.Mvc;

namespace proje_1.Controllers
{
    public class ProfilController : Controller
    {
        public IActionResult Profil()
        {
            return View();
        }
    }
}
