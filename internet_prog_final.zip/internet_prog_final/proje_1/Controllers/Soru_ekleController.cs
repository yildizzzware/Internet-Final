﻿using Microsoft.AspNetCore.Mvc;

namespace proje_1.Controllers
{
    public class Soru_ekleController : Controller
    {
        public IActionResult Soru_ekle()
        {
            return View();
        }
    }
}
