﻿using Microsoft.AspNetCore.Mvc;

namespace proje_1.Controllers
{
    public class RegisterController : Controller
    {
        public IActionResult Register()
        {
            return View();
        }
    }
}
