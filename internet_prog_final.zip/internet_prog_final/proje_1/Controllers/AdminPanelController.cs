﻿using Microsoft.AspNetCore.Mvc;

namespace proje_1.Controllers
{
    public class AdminPanelController : Controller
    {
        public IActionResult AdminPanel()
        {
            return View();
        }
    }
}
