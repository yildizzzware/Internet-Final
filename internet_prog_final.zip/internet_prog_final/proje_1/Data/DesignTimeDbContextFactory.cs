﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using proje_1.Models;
using System.IO;

namespace proje_1.Data
{
    public class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<SoruDbContext>
    {
        public SoruDbContext CreateDbContext(string[] args)
        {
            IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();

            var builder = new DbContextOptionsBuilder<SoruDbContext>();
            var connectionString = configuration.GetConnectionString("sqlCon");
            builder.UseSqlServer(connectionString);

            return new SoruDbContext(builder.Options);
        }
    }
}
